import React, { useState, useRef } from "react";
import {
  Send,
  Upload,
  Link as LinkIcon,
  ArrowLeft,
  Loader2,
} from "lucide-react";
import { Link } from "react-router-dom";
import { FinancialAgents } from "../components/FinancialAgents";

interface ApiResponse {
  message: string;
  output: string;
}

export function InvestmentPage() {
  const [userData, setUserData] = useState("");
  const [userQuery, setUserQuery] = useState("");
  const [response, setResponse] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);

  const handleSubmit = async () => {
    if (!userData || !userQuery) {
      setError("Both user data and query are required");
      return;
    }

    setLoading(true);
    setError(null);
    setResponse(null);

    try {
      const response = await fetch("http://localhost:8000/api/execute/", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          user_data: userData,
          user_query: userQuery,
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to execute query");
      }

      const data: ApiResponse = await response.json();
      setResponse(data.output);
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred");
    } finally {
      setLoading(false);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const files = Array.from(e.dataTransfer.files);
    handleFiles(files);
  };

  const handleFiles = (files: File[]) => {
    setUploadProgress(0);
    const interval = setInterval(() => {
      setUploadProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          return 100;
        }
        return prev + 10;
      });
    }, 300);
  };

  return (
    <div className="min-h-screen bg-navy-900 text-gray-100 relative overflow-hidden">
      <div className="particles-bg"></div>

      {/* Back to Home Button */}
      <Link
        to="/"
        className="fixed top-4 left-4 flex items-center space-x-2 text-gray-300 hover:text-gold transition-colors z-50"
      >
        <ArrowLeft className="w-5 h-5" />
        <span>Back to Home</span>
      </Link>

      {/* Main Content - Upper Section (75vh) */}
      <div className="h-[75vh] flex flex-col md:flex-row">
        {/* Left Side - Financial Agents */}
        <div className="w-full md:w-1/2 p-6 border-r border-navy-700">
          <div className="h-full bg-navy-800/50 rounded-xl p-6 backdrop-blur-sm border border-navy-700 relative overflow-hidden">
            <h2 className="text-2xl font-bold mb-6 bg-gradient-to-r from-gold to-blue-500 bg-clip-text text-transparent">
              AI Financial Agents Network
            </h2>
            <FinancialAgents />
          </div>
        </div>

        {/* Right Side - Response Display */}
        <div className="w-full md:w-1/2 p-6">
          <div className="h-full bg-navy-800/50 rounded-xl p-6 backdrop-blur-sm border border-navy-700 relative overflow-hidden">
            <h2 className="text-2xl font-bold mb-6 bg-gradient-to-r from-blue-500 to-gold bg-clip-text text-transparent">
              AI Response
            </h2>
            <div className="h-full overflow-auto">
              {loading ? (
                <div className="flex items-center justify-center h-full">
                  <Loader2 className="w-8 h-8 text-gold animate-spin" />
                </div>
              ) : error ? (
                <div className="bg-red-500/10 text-red-400 p-4 rounded-lg">
                  {error}
                </div>
              ) : response ? (
                <pre className="whitespace-pre-wrap text-gray-300">
                  {response}
                </pre>
              ) : (
                <div className="text-gray-400 text-center mt-8">
                  Enter your data and query below to get started
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Lower Section (25vh) */}
      <div className="h-[25vh] grid grid-cols-1 md:grid-cols-3 gap-6 p-6">
        {/* User Data Input */}
        <div className="relative group">
          <textarea
            value={userData}
            onChange={(e) => setUserData(e.target.value)}
            placeholder="Enter your financial data..."
            className="w-full h-full bg-navy-800/50 border border-navy-700 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-gold/50 backdrop-blur-sm transition-all duration-300 resize-none"
          />
        </div>

        {/* User Query Input */}
        <div className="relative group">
          <div className="flex h-full">
            <textarea
              value={userQuery}
              onChange={(e) => setUserQuery(e.target.value)}
              placeholder="Enter your query..."
              className="flex-1 bg-navy-800/50 border border-navy-700 rounded-l-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-gold/50 backdrop-blur-sm transition-all duration-300 resize-none"
            />
            <button
              onClick={handleSubmit}
              disabled={loading}
              className="px-4 bg-gold text-navy-900 rounded-r-lg hover:bg-gold/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
            >
              {loading ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <Send className="w-5 h-5" />
              )}
            </button>
          </div>
        </div>

        {/* File Upload */}
        <div className="relative">
          <input
            ref={fileInputRef}
            type="file"
            className="hidden"
            onChange={(e) =>
              e.target.files && handleFiles(Array.from(e.target.files))
            }
            multiple
          />
          <div
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            className={`h-full bg-navy-800/50 border-2 border-dashed rounded-lg backdrop-blur-sm transition-all duration-300 flex flex-col items-center justify-center cursor-pointer ${
              isDragging
                ? "border-gold bg-gold/10"
                : "border-navy-700 hover:border-gold/50"
            }`}
            onClick={() => fileInputRef.current?.click()}
          >
            <Upload className="w-8 h-8 text-gold mb-2" />
            <p className="text-sm text-gray-400">Upload or drag files here</p>
            {uploadProgress > 0 && (
              <div className="absolute bottom-0 left-0 w-full h-1 bg-navy-700 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-gold to-blue-500 transition-all duration-300"
                  style={{ width: `${uploadProgress}%` }}
                />
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
