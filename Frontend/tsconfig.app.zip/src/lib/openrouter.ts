import { ChatMessage } from '../types';

const OPENROUTER_API_KEY = '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';
const MAX_RETRIES = 3;
const RETRY_DELAY = 1000;

const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export async function sendMessage(messages: ChatMessage[], retryCount = 0): Promise<string> {
  try {
    const response = await fetch('https://api.openrouter.ai/api/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${OPENROUTER_API_KEY}`,
        'HTTP-Referer': window.location.origin,
        'X-Title': 'FinanceAI Assistant',
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Origin': window.location.origin
      },
      body: JSON.stringify({
        model: 'perplexity/r1-1776',
        messages: messages.map(msg => ({
          role: msg.role,
          content: msg.content
        })),
        temperature: 0.7,
        max_tokens: 1000,
        stream: false
      })
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.error?.message || `HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    if (!data.choices?.[0]?.message?.content) {
      throw new Error('Invalid response format from API');
    }

    return data.choices[0].message.content;
  } catch (error) {
    if (retryCount < MAX_RETRIES) {
      console.warn(`Attempt ${retryCount + 1} failed, retrying...`, error);
      await sleep(RETRY_DELAY * (retryCount + 1));
      return sendMessage(messages, retryCount + 1);
    }

    const errorMessage = error instanceof Error ? error.message : 'Failed to connect to AI service';
    console.error('Error sending message:', errorMessage);
    throw new Error('Unable to get a response from the AI service. Please try again later.');
  }
}